
<html>
	<head>
		<title>Spectral Simulation Workflow Portal</title>
		<link rel="stylesheet" href="css/style.css?id=400" type="text/css"/>
		<link rel="stylesheet" href="css/jquery.dataTables.css?id=400" type="text/css"/>
		<link rel="stylesheet" href="css/tipTip.css" type="text/css"/>	
        <link href='https://fonts.googleapis.com/css?family=Lato:400' rel='stylesheet' type='text/css'>
        <link href='https://fonts.googleapis.com/css?family=Open+Sans+Condensed:700' rel='stylesheet' type='text/css'>


		<script src="js/jquery-1.11.0.min.js"></script>
		<script src="js/jquery.tipTip.minified.js"></script>	
		<script src="js/script.js"></script>
		<script src="js/jquery.dataTables.js"></script>
		
        <script>
        function form() {
            window.location.href="userForm";
        }

        function requestData() {
            window.location.href="requestData";
        }

        </script>
	</head>
	
	<body>
        <div id="page">
        <a href="/riographx/" class="logo"><img src="img/logo.png"></a>
            
        <div class="log_reg">
            <a href="#">Login</a> or <a href="#">Create an account</a>    
        </div>
            
        <div class="clear"></div>
        
        <div id="menu">
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="desc.php">Description</a></li>
                <li class="sae"><a href="submitAnExperiment.php" onclick="form()">Submit an experiment</a></li>
                <li><a href="myExperiments.php" onclick="requestData();">My experiments</a></li>
            </ul>    
        </div>
        
        <div class="clear"></div>
            
			<!--- <div id="msgBar">
				<div id="msgBarBody" >
					<span id="msgText"></span> 
				</div>
			</div> --->
			
			
